//config default
export const firebaseConfig = {
  apiKey: "AIzaSyAvoEI5dfc57-9N3HMC-JvVhnlnotPbXug",
  authDomain: "ionic-3-restaurantapp-32a62.firebaseapp.com",
  databaseURL: "https://ionic-3-restaurantapp-32a62.firebaseio.com",
  projectId: "ionic-3-restaurantapp-32a62",
  storageBucket: "ionic-3-restaurantapp-32a62.appspot.com",
  messagingSenderId: "474869075253"
};