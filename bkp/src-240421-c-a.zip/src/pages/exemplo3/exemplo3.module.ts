import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Exemplo3Page } from './exemplo3';

@NgModule({
  declarations: [
    Exemplo3Page,
  ],
  imports: [
    IonicPageModule.forChild(Exemplo3Page),
  ],
})
export class Exemplo3PageModule {}
