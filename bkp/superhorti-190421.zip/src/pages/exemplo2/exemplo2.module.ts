import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Exemplo2Page } from './exemplo2';

@NgModule({
  declarations: [
    Exemplo2Page,
  ],
  imports: [
    IonicPageModule.forChild(Exemplo2Page),
  ],
})
export class Exemplo2PageModule {}
