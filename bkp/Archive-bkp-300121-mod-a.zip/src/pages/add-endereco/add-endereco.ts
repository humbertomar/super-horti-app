import { Component } from "@angular/core";
import { NavController, NavParams, ViewController, AlertController } from "ionic-angular";
import { AngularFireDatabase } from "@angular/fire/database";
import { AngularFireAuth } from "@angular/fire/auth";
import { map } from "rxjs/operators";
import { NgForm } from "@angular/forms";

@Component({
  selector: 'page-add-endereco',
  templateUrl: 'add-endereco.html',
})
export class AddEnderecoPage {

  public backgroundImage = 'assets/img/bg.jpg';

  address: any = {};

  addressList: any = [];

  constructor(
    public af: AngularFireAuth,
    public db: AngularFireDatabase,
    public navCtrl: NavController,
    public navParams: NavParams,

    public viewCtrl: ViewController,

    public alertCtrl: AlertController
  ) {

    var key = this.navParams.get("key");
    //console.log(key);

    if (key) {
      this.db
        .list("/users/" + this.af.auth.currentUser.uid + "/address").snapshotChanges().pipe(map(changes => changes.map(c => ({ $key: c.payload.key, ...c.payload.val() }))
        )).subscribe((res: any) => {

          this.addressList = res;
          //console.log(this.addressList);

        })
    }else{
      //this.address.cep = this.navParams.get("ncep");
      //this.address.frete = this.navParams.get("nfrete");
    }

    //this.address.cep = localStorage.getItem('cep');
    //this.address.frete = localStorage.getItem('frete');

    //this.address.bairro = localStorage.getItem("bairro");
    //this.address.endereco = localStorage.getItem("enderco");
    
    //console.log(this.address.cep);
    //console.log(this.address.frete);
    if (this.af.auth.currentUser) {
      this.db
        .list("/users/" + this.af.auth.currentUser.uid + "/address")
        .snapshotChanges()
        .pipe(
          map(changes =>
            changes.map(c => ({ $key: c.payload.key, ...c.payload.val() }))
          )
        ).subscribe((res: any) => {
          //this.addressList = res;
          //console.log(res);
        })
    }

    this.address.estado = 'GO';
    this.address.cidade = 'Goiânia';
    this.address.endereco = this.navParams.get('endereco');
    this.address.bairro = this.navParams.get('bairro');
    this.address.cep = this.navParams.get('cep');
    this.address.frete = this.navParams.get('frete');

    //console.log(this.address);

    //console.log(localStorage.getItem("bairro"));
    //console.log(localStorage.getItem("logradouro"));

  }

  addAddress(form: NgForm) {
    //console.log(this.address);
    //this.viewCtrl.dismiss({ data: this.address });
    if (this.af.auth.currentUser) {
      this.db.list("/users/" + this.af.auth.currentUser.uid + "/address").push(this.address)
        .then(res => {
          let retornoString = JSON.stringify(res);
          let resultado = retornoString.split("/address/").pop();
          let KeyAddress = resultado.replace('"', '');
          //console.log(JSON.stringify(res));
          //console.log(KeyAddress);
          this.viewCtrl.dismiss({cep: this.address.cep, frete: this.address.frete, keyAddress: KeyAddress});
        });
    }

  }

  close(data) {
    this.viewCtrl.dismiss({data:data});
  }

}
