import { Component } from "@angular/core";
import { IonicPage, NavController, LoadingController } from "ionic-angular";

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@IonicPage()
@Component({
  selector: "page-home",
  templateUrl: "home.html"
})
export class HomePage {

  font: any;

  dataSetCategory: any;
  dataSetSlider: any;

  Cart: any = [];
  noOfItems: any;

  public Categories: Array<any> = [];

  constructor(
    public navCtrl: NavController,
    public loadingCtrl: LoadingController,

    public authService: AuthServiceProvider
  ) {

    this.font = "sb-bistro-coffee";

    let loader = this.loadingCtrl.create({
      content: "Aguarde..."
    });
    loader.present().then(() => {

      this.getDataSlider();
      this.getDataCategory();

      loader.dismiss();
    });

    //localStorage.clear();//limpa o localStorage
    //localStorage.removeItem('cep');//limpa o cep do localStorage
    //localStorage.removeItem('frete');//limpa o frete do localStorage

    //console.log(localStorage.getItem('cep'));
    //console.log(localStorage.getItem('frete'));

  }

  ionViewWillEnter() {
    //console.log("ionViewWillEnter")

    this.Cart = JSON.parse(localStorage.getItem("Cart"));
    //console.log(this.Cart);

    if (this.Cart != null) {
      var i;
      var soma = 0;
      var valor = [];
      for (i = 0; i < this.Cart.length; i++) {
        //console.log(this.Cart[i].item.itemQunatity);
        valor[i] = this.Cart[i].item.itemQunatity;
        soma += valor[i];
      }
      //console.log(soma);
    }

    this.noOfItems = this.Cart != null ? soma : null;

    //this.uid = localStorage.getItem('uid');
    //console.log(this.uid);

  }

  getDataSlider() {
    this.authService.getData('sliders').then((result) => {
      //console.log(result);
      this.dataSetSlider = result;
    }, (err) => {
      console.log(err);
    });
  }

  getDataCategory() {
    this.authService.getData('category')
      .then((result) => {
        //console.log(result);
        this.dataSetCategory = result;
      }, (err) => {
        console.log(err);
      });
  }

  navigate(id) {
    this.navCtrl.push("ProductListPage", { id: id });
  }

  navcart() {
    this.navCtrl.push("CartPage");
  }

}
