import { Component } from "@angular/core";
import { IonicPage, NavController, NavParams, AlertController, ModalController} from "ionic-angular";
import { AngularFireDatabase, AngularFireList } from "@angular/fire/database";
import { AngularFireAuth } from "@angular/fire/auth";
import { map } from "rxjs/operators";

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { CheckoutPage } from "../checkout/checkout";
import { InsertCepPage } from "../insert-cep/insert-cep";
import { AddEnderecoPage } from "../add-endereco/add-endereco";
import { FirebaseServiceProvider } from "../../providers/firebase-service/firebase-service";

@IonicPage()
@Component({
  selector: "page-address-list",
  templateUrl: "address-list.html"
})
export class AddressListPage {

  public backgroundImage = 'assets/img/bg.jpg';

  dataPedidoAgendado: any;
  diaSemana: any;

  frete: any;
  cep: any;
  keyAddress: any;

  enderecoCompleto: any;

  Cart: any[] = [];

  dataSetGoogleMaps: any;

  grandTotal: any;
  subTotal: any;
  address: any = {};
  addressList: any = [];
  payTotal: any;

  cart: Array<any>;
  orderDetails: any = {};
  
  constructor(
    public af: AngularFireAuth,
    public db: AngularFireDatabase,
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,

    public authService: AuthServiceProvider,

    public modalCtrl: ModalController,

    public fbs: FirebaseServiceProvider
  ) {

    //console.log(localStorage.getItem("uid"));
    //console.log(localStorage.getItem("email"));
    //console.log(localStorage.getItem('cep'));
    //console.log(localStorage.getItem('frete'));

    this.frete = localStorage.getItem('frete');
    this.cep = localStorage.getItem('cep');
    this.keyAddress = localStorage.getItem('keyAddress');

    this.dataPedidoAgendado = this.navParams.get('dataPedidoAgendado');
    this.diaSemana = this.navParams.get('diaSemana');

    this.Cart = JSON.parse(localStorage.getItem("Cart"));
    //console.log("cart: "+JSON.stringify(this.Cart));

    this.orderDetails.grandTotal = this.navParams.get("grandTotal");
    this.payTotal = this.orderDetails.grandTotal;
    //this.orderDetails.couponDiscount = this.navParams.get("couponDiscount");
    this.orderDetails.subTotal = this.navParams.get("subTotal");
    //this.orderDetails.deductedPrice = this.navParams.get("deductedPrice");
    this.orderDetails.tax = this.navParams.get("totalVat");

    this.orderDetails.dataPedidoAgendado = this.navParams.get('dataPedidoAgendado');
    this.orderDetails.pedidoAgendado = this.navParams.get("pedidoAgendado");

    //console.log(this.orderDetails.subTotal + this.orderDetails.tax);
    //console.log(this.payTotal);

    //console.log(this.orderDetails);

    console.log(this.frete);

    if (this.orderDetails.grandTotal == undefined) {
      this.navCtrl.push("CartPage");
    }

    if (this.af.auth.currentUser) {
      
      if(this.keyAddress){
        const subscribe = this.fbs.get("/users/" + this.af.auth.currentUser.uid + "/address/", this.keyAddress).subscribe((c: any) => {
          subscribe.unsubscribe();
          let endereco = c;
          //console.log(endereco);

          this.authService.getData('settings').then((data: any[]) => {
            let settings = data;

            this.addressList.bairro = endereco.bairro;
            this.addressList.cep = endereco.cep;
            this.addressList.cidade = endereco.cidade;
            this.addressList.complemento = endereco.complemento;
            this.addressList.contato = endereco.contato;
            this.addressList.endereco = endereco.endereco;
            this.addressList.estado = endereco.estado;
            
            //console.log(this.settings);

            settings.forEach(elemento => {
              //console.log(elemento.bloquear_app);

              let shipping5 = elemento.frete_5;
              let shipping10 = elemento.frete_10;
              let shipping25 = elemento.frete_25;
              let shipping30 = elemento.frete_30;

              //console.log(endereco.frete);

              //console.log(this.converteFrete(endereco.frete));

              if (endereco.frete == 0) {
                this.addressList.frete = shipping5;
                //console.log(shipping5);
              } else if (endereco.frete == 15) {
                this.addressList.frete = shipping10;
                //console.log(shipping10);
                //console.log(shipping25);
              } else {//25
                this.addressList.frete = shipping30;
              }

              //console.log(this.addressList.frete);
              
            })

            //console.log(this.addressList.frete);

            var output = {}
            output["bairro"] = endereco.bairro;
            output["cep"] = endereco.cep;
            output["cidade"] = endereco.cidade;
            output["complemento"] = endereco.complemento;
            output["contato"] = endereco.contato;
            output["endereco"] = endereco.endereco;
            output["estado"] = endereco.estado;
            output["frete"] = this.addressList.frete;
            output["nome"] = endereco.nome;
            output["numero"] = endereco.numero;

            //console.log(JSON.stringify(output));
            //this.enderecoCompleto = JSON.stringify(output);
            //console.log(this.enderecoCompleto);

            //this.addressList.key = endereco.key;
            this.addressList.nome = endereco.nome;
            this.addressList.numero = endereco.numero;
            //console.log(this.addressList);

            //this.orderDetails.shippingAddress = '{"bairro":"'+endereco.bairro+'","cep":"'+endereco.cep+'","cidade":"'+endereco.cidade+'","complemento":"'+endereco.complemento+'","contato":"'+endereco.contato+'","endereco":"'+endereco.endereco+'","estado":"'+endereco.estgado+'","frete":"'+endereco.frete+'","nome":"'+endereco.nome+'","numero":"'+endereco.numero+'"}';
            this.orderDetails.shippingAddress = output;
            //console.log(this.orderDetails.shippingAddress);

          });

        })
      }
    }
    this.orderDetails.cart = JSON.parse(localStorage.getItem("Cart"));
  }

  converteFrete(frete){
    this.authService.getData('settings').then((data: any[]) => {
      let settings = data;

      //console.log(this.settings);

      settings.forEach(elemento => {
        //console.log(elemento.bloquear_app);

        let shipping5 = elemento.frete_5;
        let shipping10 = elemento.frete_10;
        let shipping25 = elemento.frete_25;
        let shipping30 = elemento.frete_30;

        console.log(frete);

        if (frete == 0) {
          this.addressList.frete = shipping5;
          //console.log(shipping5);
        } else if (frete == 15) {
          this.addressList.frete = shipping10;
          //console.log(shipping10);
          //console.log(shipping25);
        } else {//25
          this.addressList.frete = shipping30;
        }

        console.log(this.addressList.frete);
        return this.addressList.frete;
        
      })

    });
  }
  insertCep() {
    let profileModal = this.modalCtrl.create(InsertCepPage, { modalId: 1 });
    profileModal.present();

    profileModal.onDidDismiss(data => {
      //console.log(data.cep);
      if (data.cep != 0) {
        this.getDataGoogleMaps(data.cep);
      }
    });
  }

  getDataGoogleMaps(cep) {
    this.authService.getData('googleMaps/' + cep).then((result) => {
      //console.log(result);
      this.dataSetGoogleMaps = result;
      if (this.dataSetGoogleMaps != 'Digite um CEP válido') {
        //alert("Valor do frete: R$ "+this.dataSetGoogleMaps+',00');

        let alert = this.alertCtrl.create({
          title: 'Entregamos nesse CEP!',
          //title: 'Valor do frete: R$ '+this.dataSetGoogleMaps+',00',
          subTitle: '',
          buttons: ['OK']
        });
        alert.present();

        //this.navCtrl.setRoot("AddAddressPage");
        this.navCtrl.push("AddAddressPage", {
          id: 1
        });

        //console.log(this.dataSetGoogleMaps);
        localStorage.setItem('cep', cep);
        localStorage.setItem('frete', JSON.stringify(this.dataSetGoogleMaps));
      } else {
        let alert = this.alertCtrl.create({
          title: 'CEP inválido!',
          subTitle: '',
          buttons: [
            {
              text: 'OK',
              handler: () => {
                this.insertCep();
              }
            }
          ]
        });
        alert.present();
      }

    }, (err) => {
      console.log(err);
    });
  }

  //Selected Address
  selectAddress(key, address) {
    //this.orderDetails.shippingAddress = address;
  }

  checkOut() {
    //console.log(this.orderDetails.shippingAddress);
    //console.log(this.pincodeMatched);

    this.orderDetails.orderView = false;

    //console.log(this.orderDetails);

    if (this.orderDetails.shippingAddress) {
      //console.log(this.orderDetails);
      this.navCtrl.push(CheckoutPage, {
        orderDetails: this.orderDetails
      });
    } else {
      this.showAlert("Confirme seu endereço primeiro!");
    }
  }

  showAlert(message) {
    let alert = this.alertCtrl.create({
      title: "Desculpe!",
      subTitle: message,
      buttons: ["OK"]
    });
    alert.present();
  }

}

